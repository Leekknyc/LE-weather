local ESX = exports['es_extended']:getSharedObject()

local state = {
  weather = Config.DefaultWeather,
  hour = Config.DefaultHour,
  minute = Config.DefaultMinute,
  freezeTime = false,
  freezeWeather = false,
  blackout = Config.DefaultBlackout
}

local function isAllowed(src)
  local xPlayer = ESX.GetPlayerFromId(src)
  if not xPlayer then return false end
  local grp = xPlayer.getGroup()
  return Config.AllowedGroups[grp] == true
end

local function broadcastState()
  TriggerClientEvent('le_weather:client:applyState', -1, state)
end

lib.callback.register('le_weather:cb:canOpen', function(src)
  return isAllowed(src)
end)

lib.callback.register('le_weather:cb:getState', function(src)
  if not isAllowed(src) then
    return { ok = false, msg = "No permission." }
  end
  return { ok = true, state = state }
end)

-- Server state
local CurrentWeather = "CLEAR"
local CurrentBlackout = false
local CurrentTime = { hour = 12, minute = 0 }
local FreezeTime = false

local function broadcastState()
    TriggerClientEvent("le_weather:client:applyState", -1, {
        weather = CurrentWeather,
        blackout = CurrentBlackout,
        hour = CurrentTime.hour,
        minute = CurrentTime.minute,
        freezeTime = FreezeTime
    })
end

CreateThread(function()
    while true do
        Wait(5000)
        broadcastState()
    end
end)


RegisterNetEvent("le_weather:server:setWeather", function(weather)
    local src = source

    -- Validate input to avoid invalid weather snapping back
    local allowed = {
        CLEAR=true, EXTRASUNNY=true, CLOUDS=true, OVERCAST=true,
        RAIN=true, THUNDER=true, SMOG=true, FOGGY=true
    }
    if not allowed[weather] then return end

    CurrentWeather = weather -- ✅ THIS is the key
    FreezeWeather = true     -- optional: prevents drifting if you support random cycles

    TriggerClientEvent("le_weather:client:applyState", -1, {
        weather = CurrentWeather,
        blackout = CurrentBlackout,
        hour = CurrentTime.hour,
        minute = CurrentTime.minute,
        freezeTime = FreezeTime
    })
end)


RegisterNetEvent('le_weather:server:setTime', function(hour, minute)
  local src = source
  if not isAllowed(src) then return end

  hour = tonumber(hour)
  minute = tonumber(minute)
  if not hour or not minute then return end

  hour = math.max(0, math.min(23, math.floor(hour)))
  minute = math.max(0, math.min(59, math.floor(minute)))

  state.hour = hour
  state.minute = minute

  broadcastState()
  lib.notify(src, { description = ("Time set to %02d:%02d"):format(hour, minute), type = "success" })
end)

RegisterNetEvent('le_weather:server:setPresetTime', function(presetKey)
  local src = source
  if not isAllowed(src) then return end
  if type(presetKey) ~= "string" then return end

  local preset = Config.TimePresets[presetKey]
  if not preset then return end

  state.hour = preset.hour
  state.minute = preset.minute

  broadcastState()
  lib.notify(src, { description = ("Time preset: %s (%02d:%02d)"):format(presetKey, state.hour, state.minute), type = "success" })
end)

RegisterNetEvent('le_weather:server:setStormPreset', function()
  local src = source
  if not isAllowed(src) then return end

  state.weather = Config.StormPresetWeather or "THUNDER"
  broadcastState()
  lib.notify(src, { description = "Storm preset applied.", type = "success" })
end)

RegisterNetEvent('le_weather:server:toggleFreezeTime', function()
  local src = source
  if not isAllowed(src) then return end
  state.freezeTime = not state.freezeTime
  broadcastState()
  lib.notify(src, { description = ("Freeze Time: %s"):format(state.freezeTime and "ON" or "OFF"), type = "inform" })
end)

RegisterNetEvent('le_weather:server:toggleFreezeWeather', function()
  local src = source
  if not isAllowed(src) then return end
  state.freezeWeather = not state.freezeWeather
  broadcastState()
  lib.notify(src, { description = ("Freeze Weather: %s"):format(state.freezeWeather and "ON" or "OFF"), type = "inform" })
end)

RegisterNetEvent('le_weather:server:toggleBlackout', function()
  local src = source
  if not isAllowed(src) then return end
  state.blackout = not state.blackout
  broadcastState()
  lib.notify(src, { description = ("Blackout: %s"):format(state.blackout and "ON" or "OFF"), type = "inform" })
end)

AddEventHandler('playerJoining', function()
  local src = source
  TriggerClientEvent('le_weather:client:applyState', src, state)
end)

if Config.EnablePeriodicSync then
  CreateThread(function()
    while true do
      Wait((Config.SyncIntervalSeconds or 60) * 1000)
      broadcastState()
    end
  end)
end

CreateThread(function()
  Wait(1500)
  broadcastState()
end)
