local ESX = exports['es_extended']:getSharedObject()

local state = {
  weather = Config.DefaultWeather or "CLEAR",
  hour = Config.DefaultHour or 12,
  minute = Config.DefaultMinute or 0,
  freezeTime = false,
  freezeWeather = false,
  blackout = Config.DefaultBlackout or false
}

local function isAllowed(src)
  local xPlayer = ESX.GetPlayerFromId(src)
  if not xPlayer then return false end
  local grp = xPlayer.getGroup()
  return Config.AllowedGroups and Config.AllowedGroups[grp] == true
end

local function broadcastState()
  TriggerClientEvent('le_weather:client:applyState', -1, state)
end

-- =========================
-- Callbacks
-- =========================
lib.callback.register('le_weather:cb:canOpen', function(src)
  return isAllowed(src)
end)

lib.callback.register('le_weather:cb:getState', function(src)
  if not isAllowed(src) then
    return { ok = false, msg = "No permission." }
  end
  return { ok = true, state = state }
end)

-- =========================
-- Events
-- =========================
RegisterNetEvent('le_weather:server:setWeather', function(weather)
  local src = source
  if not isAllowed(src) then return end
  if type(weather) ~= "string" then return end

  state.weather = weather
  broadcastState()

  lib.notify(src, {
    description = ("Weather set to %s"):format(weather),
    type = "success"
  })
end)

RegisterNetEvent('le_weather:server:setTime', function(hour, minute)
  local src = source
  if not isAllowed(src) then return end

  hour = tonumber(hour)
  minute = tonumber(minute)
  if not hour or not minute then return end

  hour = math.max(0, math.min(23, math.floor(hour)))
  minute = math.max(0, math.min(59, math.floor(minute)))

  state.hour = hour
  state.minute = minute

  broadcastState()

  lib.notify(src, {
    description = ("Time set to %02d:%02d"):format(hour, minute),
    type = "success"
  })
end)

RegisterNetEvent('le_weather:server:setPresetTime', function(presetKey)
  local src = source
  if not isAllowed(src) then return end
  if type(presetKey) ~= "string" then return end

  local preset = (Config.TimePresets or {})[presetKey]
  if not preset or preset.hour == nil or preset.minute == nil then return end

  state.hour = tonumber(preset.hour) or state.hour
  state.minute = tonumber(preset.minute) or state.minute

  broadcastState()

  lib.notify(src, {
    description = ("Time preset: %s (%02d:%02d)"):format(presetKey, state.hour, state.minute),
    type = "success"
  })
end)

RegisterNetEvent('le_weather:server:setStormPreset', function()
  local src = source
  if not isAllowed(src) then return end

  state.weather = Config.StormPresetWeather or "THUNDER"
  broadcastState()

  lib.notify(src, {
    description = "Storm preset applied.",
    type = "success"
  })
end)

RegisterNetEvent('le_weather:server:toggleFreezeTime', function()
  local src = source
  if not isAllowed(src) then return end

  state.freezeTime = not state.freezeTime
  broadcastState()

  lib.notify(src, {
    description = ("Freeze Time: %s"):format(state.freezeTime and "ON" or "OFF"),
    type = "inform"
  })
end)

RegisterNetEvent('le_weather:server:toggleFreezeWeather', function()
  local src = source
  if not isAllowed(src) then return end

  state.freezeWeather = not state.freezeWeather
  broadcastState()

  lib.notify(src, {
    description = ("Freeze Weather: %s"):format(state.freezeWeather and "ON" or "OFF"),
    type = "inform"
  })
end)

RegisterNetEvent('le_weather:server:toggleBlackout', function()
  local src = source
  if not isAllowed(src) then return end

  state.blackout = not state.blackout
  broadcastState()

  lib.notify(src, {
    description = ("Blackout: %s"):format(state.blackout and "ON" or "OFF"),
    type = "inform"
  })
end)

-- =========================
-- Sync on join
-- =========================
AddEventHandler('playerJoining', function()
  local src = source
  TriggerClientEvent('le_weather:client:applyState', src, state)
end)

-- =========================
-- Periodic sync
-- =========================
if Config.EnablePeriodicSync then
  CreateThread(function()
    while true do
      Wait((Config.SyncIntervalSeconds or 60) * 1000)
      broadcastState()
    end
  end)
end

-- =========================
-- Initial broadcast
-- =========================
CreateThread(function()
  Wait(1500)
  broadcastState()
end)
