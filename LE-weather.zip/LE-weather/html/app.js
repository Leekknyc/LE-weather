const app = document.getElementById("app");
const weatherSelect = document.getElementById("weatherSelect");
const closeBtn = document.getElementById("closeBtn");

const hourEl = document.getElementById("hour");
const minuteEl = document.getElementById("minute");

const freezeTimeBtn = document.getElementById("freezeTime");
const freezeWeatherBtn = document.getElementById("freezeWeather");
const blackoutBtn = document.getElementById("blackout");

const stormPresetBtn = document.getElementById("stormPreset");

const freezeTimeState = document.getElementById("freezeTimeState");
const freezeWeatherState = document.getElementById("freezeWeatherState");
const previewText = document.getElementById("previewText");

const applyWeatherBtn = document.getElementById("applyWeather");
const applyTimeBtn = document.getElementById("applyTime");

const presetButtons = document.querySelectorAll(".preset");

let current = null;

const WEATHER_ICONS = {
  EXTRASUNNY: "☀️",
  CLEAR: "🌤️",
  CLOUDS: "☁️",
  OVERCAST: "🌥️",
  SMOG: "🌫️",
  FOGGY: "🌫️",
  CLEARING: "🌦️",
  RAIN: "🌧️",
  THUNDER: "⛈️",
  SNOW: "🌨️",
  BLIZZARD: "❄️",
  XMAS: "🎄",
  HALLOWEEN: "🎃",
  NEUTRAL: "🌡️"
};

function fmt2(n){ n = Number(n||0); return String(n).padStart(2,"0"); }
function wxLabel(w){
  const icon = WEATHER_ICONS[w] || "🌡️";
  return `${icon}  ${w}`;
}

function getResName() {
  try { if (typeof GetParentResourceName === "function") return GetParentResourceName(); }
  catch(e) {}
  return "LE-weather";
}

function post(action, data = {}) {
  const res = getResName();
  return fetch(`https://${res}/${action}`, {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=UTF-8" },
    body: JSON.stringify(data)
  }).catch(err => console.log("NUI fetch error:", err));
}

function updatePreview(){
  if (!current) return;
  const icon = WEATHER_ICONS[current.weather] || "🌡️";
  previewText.textContent =
    `Weather: ${icon} ${current.weather} • Time: ${fmt2(current.hour)}:${fmt2(current.minute)} • Blackout: ${current.blackout ? "ON" : "OFF"}`;

  freezeTimeState.textContent = `Frozen: ${current.freezeTime ? "ON" : "OFF"}`;
  freezeWeatherState.textContent = `Frozen: ${current.freezeWeather ? "ON" : "OFF"}`;
}

window.addEventListener("message", (e) => {
  const msg = e.data;
  if (!msg) return;

  if (msg.action === "open") {
    app.classList.remove("hidden");
    current = msg.state;

    weatherSelect.innerHTML = "";
    (msg.weatherTypes || []).forEach(w => {
      const opt = document.createElement("option");
      opt.value = w;
      opt.textContent = wxLabel(w);
      if (current && current.weather === w) opt.selected = true;
      weatherSelect.appendChild(opt);
    });

    hourEl.value = current.hour;
    minuteEl.value = current.minute;

    updatePreview();
  }

  if (msg.action === "close") {
    app.classList.add("hidden");
    current = null;
  }
});

closeBtn.addEventListener("click", () => post("close"));

applyWeatherBtn.addEventListener("click", () => {
  const w = weatherSelect.value;
  if (current) current.weather = w;
  updatePreview();
  post("setWeather", { weather: w });
});

applyTimeBtn.addEventListener("click", () => {
  const h = Math.max(0, Math.min(23, Number(hourEl.value || 0)));
  const m = Math.max(0, Math.min(59, Number(minuteEl.value || 0)));
  if (current){ current.hour = h; current.minute = m; }
  updatePreview();
  post("setTime", { hour: h, minute: m });
});

presetButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    const preset = btn.getAttribute("data-preset");
    post("presetTime", { preset });
  });
});

stormPresetBtn.addEventListener("click", () => {
  post("stormPreset");
});

freezeTimeBtn.addEventListener("click", () => {
  if (current) current.freezeTime = !current.freezeTime;
  updatePreview();
  post("toggleFreezeTime");
});

freezeWeatherBtn.addEventListener("click", () => {
  if (current) current.freezeWeather = !current.freezeWeather;
  updatePreview();
  post("toggleFreezeWeather");
});

blackoutBtn.addEventListener("click", () => {
  if (current) current.blackout = !current.blackout;
  updatePreview();
  post("toggleBlackout");
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") post("close");
});
