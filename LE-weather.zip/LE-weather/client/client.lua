local isOpen = false
local lastState = nil

local function applyWeather(weather)
  local transition = (Config.WeatherTransitionSeconds or 10)
  SetWeatherTypeOverTime(weather, transition + 0.0)
  Wait(transition * 1000)
  SetWeatherTypeNowPersist(weather)
  SetWeatherTypeNow(weather)
end

local function applyTime(h, m)
  NetworkOverrideClockTime(h, m, 0)
end

local function applyBlackout(enabled)
  -- Forces “dark city” effect
  SetBlackout(enabled and true or false)
end

local function openUI(state)
  if isOpen then return end
  isOpen = true
  SendNUIMessage({
    action = "open",
    state = state,
    weatherTypes = Config.WeatherTypes
  })
  Wait(50)
  SetNuiFocus(true, true)
end

local function closeUI()
  if not isOpen then return end
  isOpen = false
  SetNuiFocus(false, false)
  SendNUIMessage({ action = "close" })
end

RegisterNetEvent('le_weather:client:applyState', function(state)
  lastState = state

  applyBlackout(state.blackout)

  if state.freezeWeather then
    SetWeatherTypeNowPersist(state.weather)
    SetWeatherTypeNow(state.weather)
  else
    applyWeather(state.weather)
  end

  applyTime(state.hour, state.minute)
end)

-- Hard enforce freezes
CreateThread(function()
  while true do
    Wait(500)
    if lastState then
      if lastState.freezeTime then
        applyTime(lastState.hour, lastState.minute)
      end
      if lastState.freezeWeather then
        SetWeatherTypeNowPersist(lastState.weather)
        SetWeatherTypeNow(lastState.weather)
      end
      applyBlackout(lastState.blackout)
    end
  end
end)

RegisterCommand(Config.OpenCommand, function()
  local can = lib.callback.await('le_weather:cb:canOpen', false)
  if not can then
    lib.notify({ description = "You do not have permission.", type = "error" })
    return
  end

  local res = lib.callback.await('le_weather:cb:getState', false)
  if not res or not res.ok then
    lib.notify({ description = (res and res.msg) or "Failed to load state.", type = "error" })
    return
  end

  openUI(res.state)
end, false)

if Config.EnableKeybind then
  RegisterKeyMapping(Config.OpenCommand, 'Open Weather/Time Panel (Staff)', 'keyboard', Config.Keybind)
end

RegisterNUICallback("close", function(_, cb)
  closeUI()
  cb(true)
end)

RegisterNUICallback("setWeather", function(data, cb)
  if data and data.weather then
    TriggerServerEvent('le_weather:server:setWeather', data.weather)
  end
  cb(true)
end)

RegisterNUICallback("setTime", function(data, cb)
  TriggerServerEvent('le_weather:server:setTime', data.hour, data.minute)
  cb(true)
end)

RegisterNUICallback("presetTime", function(data, cb)
  if data and data.preset then
    TriggerServerEvent('le_weather:server:setPresetTime', data.preset)
  end
  cb(true)
end)

RegisterNUICallback("stormPreset", function(_, cb)
  TriggerServerEvent('le_weather:server:setStormPreset')
  cb(true)
end)

RegisterNUICallback("toggleFreezeTime", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleFreezeTime')
  cb(true)
end)

RegisterNUICallback("toggleFreezeWeather", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleFreezeWeather')
  cb(true)
end)

RegisterNUICallback("toggleBlackout", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleBlackout')
  cb(true)
end)

CreateThread(function()
  while true do
    Wait(0)
    if isOpen and IsControlJustReleased(0, 200) then
      closeUI()
    end
  end
end)
