local isOpen = false
local lastState = nil

-- prevents “old transition thread” from overriding new weather
local weatherToken = 0

local function applyTime(h, m)
  NetworkOverrideClockTime(tonumber(h) or 12, tonumber(m) or 0, 0)
end

local function applyBlackout(enabled)
  SetBlackout(enabled == true)
end

local function applySnowFX(enabled)
  SetForceVehicleTrails(enabled == true)
  SetForcePedFootstepsTracks(enabled == true)
end

local function hardSetWeather(w)
  ClearOverrideWeather()
  ClearWeatherTypePersist()

  SetWeatherTypeNowPersist(w)
  SetWeatherTypePersist(w)
  SetWeatherTypeNow(w)
  SetOverrideWeather(w)
end

local function applyWeather(w)
  weatherToken = weatherToken + 1
  local myToken = weatherToken

  local transition = tonumber(Config.WeatherTransitionSeconds) or 10

  -- clear anything that can block a weather change
  ClearOverrideWeather()
  ClearWeatherTypePersist()

  local snowy = (w == "XMAS" or w == "SNOW" or w == "BLIZZARD")
  applySnowFX(snowy)

  -- begin transition
  SetWeatherTypeOverTime(w, transition + 0.0)

  -- after transition, hard enforce (if not overwritten)
  CreateThread(function()
    Wait(transition * 1000)
    if myToken ~= weatherToken then return end
    hardSetWeather(w)
  end)
end

local function openUI(state)
  if isOpen then return end
  isOpen = true

  SendNUIMessage({
    action = "open",
    state = state,
    weatherTypes = Config.WeatherTypes
  })

  Wait(50)
  SetNuiFocus(true, true)
end

local function closeUI()
  if not isOpen then return end
  isOpen = false
  SetNuiFocus(false, false)
  SendNUIMessage({ action = "close" })
end

-- =========================
-- Apply state from server
-- =========================
RegisterNetEvent('le_weather:client:applyState', function(state)
  lastState = state

  applyBlackout(state.blackout)
  applyTime(state.hour, state.minute)

  if state.freezeWeather then
    -- stop any transitions and hard enforce instantly
    weatherToken = weatherToken + 1

    local w = state.weather
    local snowy = (w == "XMAS" or w == "SNOW" or w == "BLIZZARD")
    applySnowFX(snowy)

    hardSetWeather(w)
  else
    applyWeather(state.weather)
  end

  -- Keep UI preview in sync if menu is open
  if isOpen then
    SendNUIMessage({ action = "syncState", state = state })
  end
end)

-- =========================
-- Enforce freezes continuously
-- =========================
CreateThread(function()
  while true do
    Wait(500)
    if lastState then
      applyBlackout(lastState.blackout)

      if lastState.freezeTime then
        applyTime(lastState.hour, lastState.minute)
      end

      if lastState.freezeWeather then
        local w = lastState.weather
        local snowy = (w == "XMAS" or w == "SNOW" or w == "BLIZZARD")
        applySnowFX(snowy)
        hardSetWeather(w)
      end
    end
  end
end)

-- =========================
-- Open command (staff only)
-- =========================
RegisterCommand(Config.OpenCommand, function()
  local can = lib.callback.await('le_weather:cb:canOpen', false)
  if not can then
    lib.notify({ description = "You do not have permission.", type = "error" })
    return
  end

  local res = lib.callback.await('le_weather:cb:getState', false)
  if not res or not res.ok then
    lib.notify({ description = (res and res.msg) or "Failed to load state.", type = "error" })
    return
  end

  openUI(res.state)
end, false)

if Config.EnableKeybind then
  RegisterKeyMapping(Config.OpenCommand, 'Open Weather/Time Panel (Staff)', 'keyboard', Config.Keybind)
end

-- =========================
-- NUI Callbacks
-- =========================
RegisterNUICallback("close", function(_, cb)
  closeUI()
  cb(true)
end)

RegisterNUICallback("setWeather", function(data, cb)
  if data and data.weather then
    TriggerServerEvent('le_weather:server:setWeather', data.weather)
  end
  cb(true)
end)

RegisterNUICallback("setTime", function(data, cb)
  if data then
    TriggerServerEvent('le_weather:server:setTime', data.hour, data.minute)
  end
  cb(true)
end)

RegisterNUICallback("presetTime", function(data, cb)
  if data and data.preset then
    TriggerServerEvent('le_weather:server:setPresetTime', data.preset)
  end
  cb(true)
end)

RegisterNUICallback("stormPreset", function(_, cb)
  TriggerServerEvent('le_weather:server:setStormPreset')
  cb(true)
end)

RegisterNUICallback("toggleFreezeTime", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleFreezeTime')
  cb(true)
end)

RegisterNUICallback("toggleFreezeWeather", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleFreezeWeather')
  cb(true)
end)

RegisterNUICallback("toggleBlackout", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleBlackout')
  cb(true)
end)

-- ESC close
CreateThread(function()
  while true do
    Wait(0)
    if isOpen and IsControlJustReleased(0, 200) then
      closeUI()
    end
  end
end)
