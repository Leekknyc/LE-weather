local isOpen = false
local lastState = nil

local LocalTime = { hour = 12, minute = 0 }


local function applyWeather(weather)
    ClearOverrideWeather()
    ClearWeatherTypePersist()

    SetWeatherTypeOvertimePersist(weather, 15.0)
    Wait(1500)
    SetWeatherTypePersist(weather)
    SetWeatherTypeNowPersist(weather)
    SetWeatherTypeNow(weather)
end

RegisterNetEvent("le_weather:client:applyState", function(state)
    if state.weather then
        applyWeather(state.weather)
    end

    if state.blackout ~= nil then
        SetBlackout(state.blackout == true)
    end

    if state.hour ~= nil and state.minute ~= nil then
        LocalTime.hour = tonumber(state.hour) or LocalTime.hour
        LocalTime.minute = tonumber(state.minute) or LocalTime.minute
        NetworkOverrideClockTime(LocalTime.hour, LocalTime.minute, 0)
    end

    if state.freezeTime ~= nil then
        PauseClock(state.freezeTime == true)
    end
end)



local function applyTime(h, m)
  NetworkOverrideClockTime(h, m, 0)
end

local function applyBlackout(enabled)
  -- Forces “dark city” effect
  SetBlackout(enabled and true or false)
end

local LocalTime = { hour = 12, minute = 0 }

local function applyWeather(weather)
    ClearOverrideWeather()
    ClearWeatherTypePersist()

    SetWeatherTypeOvertimePersist(weather, 15.0)
    Wait(1500)
    SetWeatherTypePersist(weather)
    SetWeatherTypeNowPersist(weather)
    SetWeatherTypeNow(weather)
end




RegisterNetEvent("le_weather:client:setWeather", function(weather, blackout)
    SetWeatherTypeOvertimePersist(weather, 15.0)
    Wait(1500)
    SetWeatherTypePersist(weather)
    SetWeatherTypeNowPersist(weather)

    SetBlackout(blackout == true)
end)


RegisterNetEvent("le_weather:client:setTime", function(hour, minute, freeze)
    NetworkOverrideClockTime(hour, minute, 0)
    PauseClock(freeze == true)
end)


local function openUI(state)
  if isOpen then return end
  isOpen = true
  SendNUIMessage({
    action = "open",
    state = state,
    weatherTypes = Config.WeatherTypes
  })
  Wait(50)
  SetNuiFocus(true, true)
end

local function closeUI()
  if not isOpen then return end
  isOpen = false
  SetNuiFocus(false, false)
  SendNUIMessage({ action = "close" })
end




-- Hard enforce freezes
CreateThread(function()
  while true do
    Wait(500)
    if lastState then
      if lastState.freezeTime then
        applyTime(lastState.hour, lastState.minute)
      end
      if lastState.freezeWeather then
        SetWeatherTypeNowPersist(lastState.weather)
        SetWeatherTypeNow(lastState.weather)
      end
      applyBlackout(lastState.blackout)
    end
  end
end)

RegisterCommand(Config.OpenCommand, function()
  local can = lib.callback.await('le_weather:cb:canOpen', false)
  if not can then
    lib.notify({ description = "You do not have permission.", type = "error" })
    return
  end

  local res = lib.callback.await('le_weather:cb:getState', false)
  if not res or not res.ok then
    lib.notify({ description = (res and res.msg) or "Failed to load state.", type = "error" })
    return
  end

  openUI(res.state)
end, false)

if Config.EnableKeybind then
  RegisterKeyMapping(Config.OpenCommand, 'Open Weather/Time Panel (Staff)', 'keyboard', Config.Keybind)
end

RegisterNUICallback("close", function(_, cb)
  closeUI()
  cb(true)
end)

RegisterNUICallback("setWeather", function(data, cb)
  if data and data.weather then
    TriggerServerEvent('le_weather:server:setWeather', data.weather)
  end
  cb(true)
end)

RegisterNUICallback("setTime", function(data, cb)
  TriggerServerEvent('le_weather:server:setTime', data.hour, data.minute)
  cb(true)
end)

RegisterNUICallback("presetTime", function(data, cb)
  if data and data.preset then
    TriggerServerEvent('le_weather:server:setPresetTime', data.preset)
  end
  cb(true)
end)

RegisterNUICallback("stormPreset", function(_, cb)
  TriggerServerEvent('le_weather:server:setStormPreset')
  cb(true)
end)

RegisterNUICallback("toggleFreezeTime", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleFreezeTime')
  cb(true)
end)

RegisterNUICallback("toggleFreezeWeather", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleFreezeWeather')
  cb(true)
end)

RegisterNUICallback("toggleBlackout", function(_, cb)
  TriggerServerEvent('le_weather:server:toggleBlackout')
  cb(true)
end)

CreateThread(function()
  while true do
    Wait(0)
    if isOpen and IsControlJustReleased(0, 200) then
      closeUI()
    end
  end
end)
