Config = {}

Config.AllowedGroups = {
  admin = true,
  superadmin = true,
  mod = true,
  management = true,
  leadadmin = true,
  senioradmin = true
}

Config.OpenCommand = "weather"
Config.EnableKeybind = false
Config.Keybind = "F10"

Config.DefaultWeather = "CLEAR"
Config.DefaultHour = 12
Config.DefaultMinute = 0
Config.DefaultBlackout = false

Config.WeatherTransitionSeconds = 10

Config.EnablePeriodicSync = true
Config.SyncIntervalSeconds = 60

Config.WeatherTypes = {
  "EXTRASUNNY","CLEAR","CLOUDS","SMOG","FOGGY","OVERCAST",
  "RAIN","THUNDER","CLEARING","NEUTRAL","SNOW","BLIZZARD",
  "XMAS","HALLOWEEN"
}

-- Preset times
Config.TimePresets = {
  morning = { hour = 9,  minute = 0 },
  noon    = { hour = 12, minute = 0 },
  sunset  = { hour = 19, minute = 30 },
  night   = { hour = 23, minute = 0 },
}

-- Preset weather for "storm"
Config.StormPresetWeather = "THUNDER"
